<?php
class lsSmarty extends Smarty {
		
}