<?php 
if (!defined("LS_DKCACHE_PATH"))
  define("LS_DKCACHE_PATH", dirname(__FILE__).'/');
?>