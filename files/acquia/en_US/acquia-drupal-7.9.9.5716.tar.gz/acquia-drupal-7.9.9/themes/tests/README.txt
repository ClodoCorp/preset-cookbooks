
The themes in this subdirectory are all used by the Drupal core testing
framework. They are not functioning themes that could be used on a real site
and are hidden in the administrative user interface.
