# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_default_session',
  :secret      => '5b45401dc3e16a334b46657304bbc7402273d439b65328eae35c2fa341c2a30503d9c0c3b2002e7362cdd3014338a0527e8e189e6c22d46d3e5e797d21c65e73'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
