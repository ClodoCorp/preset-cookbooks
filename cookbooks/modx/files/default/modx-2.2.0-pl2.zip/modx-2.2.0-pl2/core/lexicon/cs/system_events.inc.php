<?php
/**
 * System Events Czech lexicon topic
 *
 * @language cs
 * @package modx
 * @subpackage lexicon
 *
 * @author modxcms.cz
 * @updated 2011-10-23
 */

// $_lang['clear'] = 'Clear';
$_lang['clear'] = 'Vymazat';

// $_lang['error_log'] = 'Error Log';
$_lang['error_log'] = 'Chybové zprávy';

// $_lang['error_log_desc'] = 'Here is the error log for MODX Revolution:';
$_lang['error_log_desc'] = 'Chybové zprávy z MODX Revolution:';

// $_lang['system_events'] = 'System Events';
$_lang['system_events'] = 'Systémové události';

// $_lang['priority'] = 'Priority';
$_lang['priority'] = 'Priorita';
