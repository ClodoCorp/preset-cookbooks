<?php
/**
 * Mail Estonian lexicon topic
 *
 * @language et
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Peate andma emaili aadressi kuhu saata.';
$_lang['mail_err_derive_getmailer'] = 'Katse kutsuda abstract function _getMailer() modMail classis. Te peate selle funktsiooni tuletama modMail-ist';
$_lang['mail_err_attr_nv'] = '[[+attr]] ei ole kehtiv PHPMailer attribuut, seda ignoreeritakse.';

$_lang['mail_err_unset_spec'] = 'modPHPMailer ei toeta spetsiifiliste aadressite eemaldamist. Kasuta reset(), et eemaldada kõik saajad ja lisada need saajad kellele soovite saata.';
