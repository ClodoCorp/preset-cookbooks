<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Clear';
$_lang['error_log'] = 'Error Log';
$_lang['error_log_desc'] = 'Here is the error log for MODX Revolution:';
$_lang['system_events'] = 'System Events';
$_lang['priority'] = 'Priority';