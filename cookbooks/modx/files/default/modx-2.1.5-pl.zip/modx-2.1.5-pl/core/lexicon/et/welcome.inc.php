<?php
/**
 * Welcome Estonian lexicon topic
 *
 * @language et
 * @package modx
 * @subpackage lexicon
 */
$_lang['modx_news'] = 'MODX Uudised';
$_lang['security_notices'] = 'Turva Teated';
$_lang['welcome_messages'] = 'Teie Inbox sisaldab <strong>%d</strong> teade(t), millest <strong>%s</strong> on lugemata.';
$_lang['welcome_title'] = 'Teretulemast MODX Sisuhaldusesse';
$_lang['yourinfo_message'] = 'Siin kuvatakse osalist informatsiooni teie kohta:';
$_lang['yourinfo_previous_login'] = 'Teie viimane sisselogimine:';
$_lang['yourinfo_title'] = 'Teie info';
$_lang['yourinfo_total_logins'] = 'Kokku sisselogimisi:';
$_lang['yourinfo_username'] = 'Olete sisseloginud kui:';
