<?php
/**
 * Mail Italian lexicon topic
 *
 * @language it
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Devi fornire un indirizzo e-mail al quale spedire il messaggio.';
$_lang['mail_err_derive_getmailer'] = 'Tentativo di eseguire la funzione astratta _getMailer() nella classe modMail. Devi implementare questa funzione in un derivato di modMail.';
$_lang['mail_err_attr_nv'] = '[[+attr]] non è un  attributo PHPMailer valido ed è attualmente ignorato dall\'implementazione.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer non supporta la disattivazione di  specifici indirizzi. Usa  reset() per cancellare tutti i destinatari e aggiungi nuovamente quelli ai quali vuoi spedire il messaggio.';