<?php
/**
 * Mail Czech lexicon topic
 *
 * @language cs
 * @package modx
 * @subpackage lexicon
 *
 * @author modxcms.cz
 * @updated 2010-07-18
 */
$_lang['mail_err_address_ns'] = 'Cílová e-mailová adresa musí být vyplněna.';
$_lang['mail_err_derive_getmailer'] = 'Pokus o zavolání abstraktní funkce _getMailer() ve třídě modMail. Musíte implementovat tuto funkci v odloučeninách modMail.';
$_lang['mail_err_attr_nv'] = '[[+attr]] není platným atributem PHPMaileru a bude implementací ignorován.';

$_lang['mail_err_unset_spec'] = 'modPHPMailer nepodporuje nenastavení dané adresy. Použijte reset() pro smazání všech příjemců a následně přidejte toho, kterého chcete.';